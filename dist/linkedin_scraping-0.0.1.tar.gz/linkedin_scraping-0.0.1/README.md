# package_name

Description. 
	Scraping de dados de vagas e analise da rede Linkedin

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install linkedin_scraping
```


## Author
EdA

## License
[MIT](https://choosealicense.com/licenses/mit/)